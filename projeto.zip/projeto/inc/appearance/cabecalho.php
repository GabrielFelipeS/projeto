<?#php include './projeto/inc/path.php' ?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
  <title>Bibliotex</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <link rel="stylesheet" type="text/css" href="/projeto/assets/css/style.css" />
  <link rel="shortcut icon" href="/projeto/assets/images/livro_icon.png" type="image/png">
  <link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,600,700&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.2/css/all.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap">
  <link rel="stylesheet" href="/projeto/assets/mdb/css/bootstrap.min.css">
  <link rel="stylesheet" href="/projeto/assets/mdb/css/style.css">
   <!--  
  
-->
    
