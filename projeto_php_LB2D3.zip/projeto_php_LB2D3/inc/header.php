
<header>
    <div class="header">
        <div class="logo">
            <div class="logoimg"><img src="./assets/images/livro_icon.png" alt="icone livro"></div>
        </div>
        <div class="menu">
            <img class="menu-opener" src="assets/images/menu.png" onclick="clickMenu()"/>
            <nav id="nav">
                <ul>
                    <li class="active"><a href="../Meu projeto/index.php#">Home</a></li>
                    <li><a href="../Meu projeto/index.php#Empresa">Empresa</a></li>
                    <li><a href="../Meu projeto/index.php#Servicos">Serviços</a></li>
                    <li><a href="../Meu projeto/index.php#Livros">Livros</a></li>
                    <li><a href="../Meu projeto/index.php#autor">Autores</a></li>
                    <li><a href="../Meu projeto/index.php#Clientes">Clientes</a></li>
                    <li><a href="../Meu projeto/index.php#Preco">Preço</a></li>
                    <li><a href="../Meu projeto/index.php#Detalhes">Detalhes</a></li>
                    <li><a href="../Meu projeto/index.php#Sugestoes">Sugestoes</a></li>
                    <li><a href="../Meu projeto/exibirCompras.php">Vendas</a></li>
                </ul>
            </nav>
        </div>
    </div>