<?php
include './inc/connection.php';


if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Retrieve user input
    $email = $_POST["email"];
    $senha = $_POST["senha"];

    // Validate user input (you should add more validation)

    // Create a prepared statement
    $stmt = mysqli_prepare($connection, "SELECT * FROM usuario WHERE email = ? AND senha = ?");

    if ($stmt) {
        // Bind the parameters
        mysqli_stmt_bind_param($stmt, "ss", $email, $senha);

        // Execute the statement
        mysqli_stmt_execute($stmt);

        // Bind the result
        mysqli_stmt_bind_result($stmt, $id, $dbEmail, $dbSenha);

        // Fetch the result
        mysqli_stmt_fetch($stmt);

        if ($dbEmail && $dbSenha) {
            // User found, log them in
            session_start();
            $_SESSION["email"] = $email;
            header("Location: dashboard.php"); // Redirect to the user's dashboard or another page
            exit();
        } else {
            // Invalid email or password, display an error message
            echo "Invalid email or password";
        }

        // Close the statement
        mysqli_stmt_close($stmt);
    } else {
        // Database query error
        echo "Database error: " . mysqli_error($connection);
    }
} else {
    // Invalid request method
    echo "Invalid request method";
}
?>
