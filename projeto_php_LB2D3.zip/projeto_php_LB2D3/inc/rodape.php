   
<script type="text/javascript" src="./assets/mdb/js/jquery.min.js"></script>
<script type="text/javascript" src="./assets/mdb/js/popper.min.js"></script>
<script type="text/javascript" src="./assets/mdb/js/bootstrap.min.js"></script>
<script type="text/javascript" src="./assets/mdb/js/mdb.min.js"></script>
<script type="text/javascript"></script>
<script src="./assets/js/index.js"></script>