<?php include './inc/cabecalho.php'; ?>
<?php include './inc/connection.php'; ?>
</head>

<body>
  <style>
    /* Adicione este CSS para desabilitar a rolagem e definir a cor da borda como preta */
    html, body {
      overflow: hidden;
      height: 100%;
      margin: 0;
      padding: 0;
    }

    body {
      background-color: black;
    }

    .container {
      display: flex;
      justify-content: center;
      align-items: flex-end; /* Alinhar o conteúdo na parte inferior do contêiner */
      height: 70vh; /* Ajusta a altura para ocupar toda a tela verticalmente */
    }

    .login-form {
      background-color: white;
      padding: 40px;
      border-radius: 20px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      text-align: center;
      max-width: 600px;
      width: 100%;
      box-sizing: border-box;
      border: 2px solid black; /* Define a cor da borda como preta */

      /* Estilize as entradas de email e senha com bordas pretas */
#email,
#senha {
  border: 2px solid black;
  border-radius: 10px;
  padding: 10px;
  width: 100%;
  margin-bottom: 20px;
}

    }
  </style>
  <header>
    <div class="header">
      <div class="logo">
        <div class="logoimg"><img src="./assets/images/livro_icon.png" alt="icone livro"></div>
      </div>
      <h2>BIBLIOTEX</h2>
    </div>
  </header>

  <main>
    <section>
      <div class="container">
        <div class="login-form">
          <form method="POST" action="./inc/login-processamento.php">
            <div class="form-group">
              <label for="email">Email:</label>
              <input type="email" id="email" name="email" required class="rounded-input">
            </div>

            <div class="form-group">
              <label for="senha">Senha:</label>
              <input type="password" id="senha" name="senha" required class="rounded-input">
            </div>

            <input type="submit" value="Login" class="button" />
          </form>
          <div class="section-fact"><p>Ainda não possui cadastro? <a href="cadastrar-usuario.php">Cadastre-se</a>.</p></div>
        </div>
      </div>
    </section>
  </main>
</body>
</html>
<style>
  .form-group {
    margin-bottom: 20px;
  }

  label {
    display: block;
  }

  .button {
    padding: 15px 30px;
  }

  .rounded-input {
    width: 100%;
    padding: 15px;
    border: none;
    border-radius: 10px;
    margin: 0;
  }
</style>
