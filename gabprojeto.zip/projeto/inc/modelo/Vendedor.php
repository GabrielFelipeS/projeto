<?php

class Vendedor {
    function __construct() {
        
    }

}