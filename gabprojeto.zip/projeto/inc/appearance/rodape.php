   
<script type="text/javascript" src="/projeto/assets/mdb/js/jquery.min.js"></script>
<script type="text/javascript" src="/projeto/assets/mdb/js/popper.min.js"></script>
<script type="text/javascript" src="/projeto/assets/mdb/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/projeto/assets/mdb/js/mdb.min.js"></script>
<script type="/projeto/text/javascript"></script>
<script src="/projeto/assets/js/index.js"></script>