<section class="default section-companies">
              <div class="section-body">
                  <div class="section-companies--area">
                      <div class="section-company">
                        <img src="media/adidas.png" />
                      </div>         
                      <div class="section-company">
                          <img src="media/disney.png" />
                      </div>
                      <div class="section-company">
                        <img src="media/Rockstar.png" />
                      </div>
                      <div class="section-company">
                          <img src="media/microsoft.webp" />
                      </div>            
                      <div class="section-company">
                          <img src="media/samsung.png" />
                      </div>
                      <div class="section-company">
                          <img src="media/sanofi.png" />
                      </div>             
                  </div>
              </div>
          </section>